package isp.lab6.exercise2;

public class Exercise2 {
    public static void main(String[] args) {
    }
}
