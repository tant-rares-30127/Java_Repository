package isp.lab6.exercise3;

public enum SENSOR_TYPE {
    TEMPERATURE, HUMIDITY, PRESSURE;
}
