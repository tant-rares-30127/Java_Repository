
package isp.lab6.exercise4;

public abstract class Transaction {
    
    public abstract String execute();
}
