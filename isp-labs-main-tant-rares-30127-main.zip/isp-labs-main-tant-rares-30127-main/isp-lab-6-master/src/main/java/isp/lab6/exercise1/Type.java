package isp.lab6.exercise1;

public enum Type {
    TEMPERATURE, HUMIDITY, PRESSURE;
}
