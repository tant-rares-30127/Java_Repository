package isp.lab6.exercise5;

public class Exercise5 {
}
