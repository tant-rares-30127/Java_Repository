package isp.lab3.exercise6;

public class Exercise6 {
}
