package isp.lab3.exercise4;

public class Exercise4 {
}
