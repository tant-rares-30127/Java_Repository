package isp.lab3.exercise5;

public class Exercise5 {
}
