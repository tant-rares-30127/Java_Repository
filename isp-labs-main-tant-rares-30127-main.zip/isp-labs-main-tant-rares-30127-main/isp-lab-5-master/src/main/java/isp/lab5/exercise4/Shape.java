
package isp.lab5.exercise4;

public interface Shape {
     void draw();
}
