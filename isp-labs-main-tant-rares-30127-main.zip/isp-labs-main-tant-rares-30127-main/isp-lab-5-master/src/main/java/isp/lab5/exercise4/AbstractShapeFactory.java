
package isp.lab5.exercise4;

public abstract class AbstractShapeFactory {
    
        /**
     * Get specific shape by type
     * @param type - one of the values ("rectangle", "roundedRectangle", "square", "roundedSquare")
     * @return instance of shape by desired type
     */
    abstract Shape getShape(String type);
    
}
