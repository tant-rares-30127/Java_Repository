package isp.lab5.exercise6;

public class Exercise6 {
}
