
package isp.lab5.exercise4;

public class Square implements Shape {
    
    @Override
    public void draw() {
        System.out.println("A square is drawn");
    }
}
