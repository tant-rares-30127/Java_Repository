
package isp.lab5.exercise4;

public class RoundedSquare implements Shape{
    @Override
    public void draw() {
        System.out.println("A rounded square is drawn");
    }
}
