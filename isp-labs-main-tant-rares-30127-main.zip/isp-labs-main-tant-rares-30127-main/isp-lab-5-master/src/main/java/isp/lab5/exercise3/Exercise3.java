package isp.lab5.exercise3;

public class Exercise3 {
}
