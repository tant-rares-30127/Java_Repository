package isp.lab5.exercise5;

public class Exercise5 {
}
