
package isp.lab5.exercise1;

public abstract class Transaction {
    
    public abstract String execute();
}
