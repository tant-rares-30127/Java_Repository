
package isp.lab7.safehome;

public class TenantNotFoundException extends Exception{
    
}
