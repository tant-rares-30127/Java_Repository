
package isp.lab9.exercise3;

public class TooManyAttemptsException extends Exception{
    
}
