
package isp.lab9.exercise3;

public class AccessKey {
    private String pin;

    public AccessKey(String pin) {
        this.pin = pin;
    }
    
    public String getPin() {
        return pin;
    }
    
}
