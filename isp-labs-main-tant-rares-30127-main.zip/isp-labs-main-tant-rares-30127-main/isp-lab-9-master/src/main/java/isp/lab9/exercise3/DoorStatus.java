package isp.lab9.exercise3;
public enum DoorStatus {
     OPEN, CLOSE;
}
