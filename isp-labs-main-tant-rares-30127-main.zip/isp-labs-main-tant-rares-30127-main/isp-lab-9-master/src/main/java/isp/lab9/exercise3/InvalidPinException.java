
package isp.lab9.exercise3;

public class InvalidPinException extends Exception{
    
}
