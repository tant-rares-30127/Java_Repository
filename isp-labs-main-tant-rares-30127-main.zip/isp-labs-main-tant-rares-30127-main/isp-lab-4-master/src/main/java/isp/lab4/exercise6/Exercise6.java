package isp.lab4.exercise6;

public class Exercise6 {
}
