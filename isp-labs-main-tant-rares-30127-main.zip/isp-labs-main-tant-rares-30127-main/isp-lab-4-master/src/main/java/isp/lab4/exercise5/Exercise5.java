package isp.lab4.exercise5;

public class Exercise5 {
}
