
package isp.lab10.exercise1;

public abstract class AtcCommand {
    
    public abstract void execute(int altitude);
}
